
# Hızlı On — 14 Gün Gerçek Yaşam İzi App

Bu Streamlit uygulaması Hızlı On çekiliş verisini gün gün işler.

## Veri biçimi
Her satır:
çekiliş_no;tarih saat;20_sayı

Örnek:
51213;25.08.2026 00:02;2,4,6,9,13,18,19,20,21,24,32,34,40,48,51,55,61,62,63,80

## Temel kural
Bir çekilişte çıkan her sayı için yalnızca o çekilişten ÖNCEKİ en son görünüm aranır:
- son çekilişte görüldüyse H-1
- iki çekiliş önce görüldüyse H-2
- ...
- o gün daha önce hiç görünmediyse Yeni

Gelecek çekiliş bilgisi kullanılmaz.

## Üretilen tek rapor
- çekiliş bazlı H-yaş izi
- günlük H-katman dağılımı
- H1-H3 / H4-H6 / H7-H14 / H15+ / Yeni
- günlük sıcak20
- saatlik sıcak20
- 01:02 → 07:02 yaşam devamlılığı
- 1–80 sayı yaşam kartları
- 14 gün birleşik makro özet
- tek TXT indirme

## Çalıştırma
pip install -r requirements.txt
streamlit run app.py

## GitHub
App içinde GitHub dosyasının:
- raw.githubusercontent.com bağlantısını
veya
- github.com/.../blob/... bağlantısını
girebilirsin.
