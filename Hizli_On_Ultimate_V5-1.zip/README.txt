Hızlı On Ultimate V5

Dosyalar:
- uygulama.py
- veri.txt
- requirements.txt

Streamlit ana dosya yolu: uygulama.py

Yeni veri yükleme:
- Uygulama içinden TXT, CSV, XLSX, XLS dosyası yüklenebilir.
- Dosyalar mevcut ana havuzla birleştirilir.
- Güncel veri.txt, CSV ve Excel olarak indirilebilir.

Not:
Streamlit Community Cloud üzerinde dosyaya kalıcı yazma yapılmaz.
Kalıcı güncelleme için indirilen veri.txt GitHub'daki veri.txt üzerine yüklenmelidir.
